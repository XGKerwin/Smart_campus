package com.example.Smart_campus.bean;

/**
 * @author 关鑫
 * @date 2021/6/7 17:18 星期一
 */

public class Work_nature_bean {

    /**
     * id
     * workNatureName
     */

    private String id;
    private String workNatureName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWorkNatureName() {
        return workNatureName;
    }

    public void setWorkNatureName(String workNatureName) {
        this.workNatureName = workNatureName;
    }
}
