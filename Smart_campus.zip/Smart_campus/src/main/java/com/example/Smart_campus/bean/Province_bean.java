package com.example.Smart_campus.bean;

/**
 * @author 关鑫
 * @date 2021/6/7 16:28 星期一
 */

public class Province_bean {

    /**
     * id
     * provinceId
     * provinceName
     */

    private String id;
    private String provinceId;
    private String provinceName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }
}
