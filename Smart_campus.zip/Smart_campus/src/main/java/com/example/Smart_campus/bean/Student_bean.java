package com.example.Smart_campus.bean;

/**
 * @author 关鑫
 * @date 2021/6/8 15:33 星期二
 */

public class Student_bean {

    /**
     * id
     * name
     * municipalld
     * povertyStudent
     * sex
     * grade
     * expenditure
     * majorld
     * wordNatureld
     * yu
     * shu
     * wai
     * wai
     */


    private String id;
    private String name;
    private String municipalld;
    private String povertyStudent;
    private String sex;
    private String grade;
    private String expenditure;
    private String majorld;
    private String wordNatureld;
    private String yu;
    private String shu;
    private String wai;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMunicipalld() {
        return municipalld;
    }

    public void setMunicipalld(String municipalld) {
        this.municipalld = municipalld;
    }

    public String getPovertyStudent() {
        return povertyStudent;
    }

    public void setPovertyStudent(String povertyStudent) {
        this.povertyStudent = povertyStudent;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getExpenditure() {
        return expenditure;
    }

    public void setExpenditure(String expenditure) {
        this.expenditure = expenditure;
    }

    public String getMajorld() {
        return majorld;
    }

    public void setMajorld(String majorld) {
        this.majorld = majorld;
    }

    public String getWordNatureld() {
        return wordNatureld;
    }

    public void setWordNatureld(String wordNatureld) {
        this.wordNatureld = wordNatureld;
    }

    public String getYu() {
        return yu;
    }

    public void setYu(String yu) {
        this.yu = yu;
    }

    public String getShu() {
        return shu;
    }

    public void setShu(String shu) {
        this.shu = shu;
    }

    public String getWai() {
        return wai;
    }

    public void setWai(String wai) {
        this.wai = wai;
    }
}
